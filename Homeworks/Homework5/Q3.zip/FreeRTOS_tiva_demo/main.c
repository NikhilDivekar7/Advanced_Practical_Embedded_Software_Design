//FreeRTOS LED Task

#include <stdint.h>
#include <stdbool.h>
#include "main.h"
#include "drivers/pinout.h"
#include "driverlib/gpio.h"
#include "utils/uartstdio.h"
#include "inc/hw_memmap.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

// FreeRTOS includes
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

// Demo Task declarations
void LED1Task(void *pvParameters);
void LED2Task(void *pvParameters);
void TimerCallback1(TimerHandle_t xTimer1);
void TimerCallback2(TimerHandle_t xTimer2);

int a, b;

// Main function
int main(void)
{
    // Initialize system clock to 120 MHz
    uint32_t output_clock_rate_hz;
    output_clock_rate_hz = ROM_SysCtlClockFreqSet(
                               (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                               SYSTEM_CLOCK);
    ASSERT(output_clock_rate_hz == SYSTEM_CLOCK);

    // Initialize the GPIO pins for the Launchpad
    PinoutSet(false, false);

    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);
    a = 0x00;
    b = 0x00;

    // Create demo tasks
    xTaskCreate(LED1Task, (const portCHAR *)"LED1",
                configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    xTaskCreate(LED2Task, (const portCHAR *)"LED2",
                configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    vTaskStartScheduler();

    return 0;
}

void TimerCallback1(TimerHandle_t xTimer1)
{
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, a);
    a ^= GPIO_PIN_0;
}

void TimerCallback2(TimerHandle_t xTimer2)
{
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, b);
    b ^= GPIO_PIN_1;
}

// Flash the LEDs on the launchpad
void LED1Task(void *pvParameters)
{
    TimerHandle_t xTimer1 = NULL;
    xTimer1 = xTimerCreate("MyTimer1", pdMS_TO_TICKS(500), pdTRUE, (void *)pvTimerGetTimerID(xTimer1), TimerCallback1);
    xTimerStart(xTimer1, 500);
    while(1);
}


// Write text over the Stellaris debug interface UART port
void LED2Task(void *pvParameters)
{
    TimerHandle_t xTimer2 = NULL;
    xTimer2 = xTimerCreate("MyTimer2", pdMS_TO_TICKS(250), pdTRUE, (void *)pvTimerGetTimerID(xTimer2), TimerCallback2);
    xTimerStart(xTimer2, 250);
    while(1);
}

/*  ASSERT() Error function
 *
 *  failed ASSERTS() from driverlib/debug.h are executed in this function
 */
void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}
